export * from './newman.component';
