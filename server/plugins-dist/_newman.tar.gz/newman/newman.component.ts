import {Component} from '@angular/core';
import {PostalService} from '../../../_services/postal.service';
@Component({
  selector: 'newman',
  template: `
    <webpage [sourceUrl]="sourceUrl"></webpage>
  `
})
export class Newman {
  sourceUrl = '/newman';
  //noinspection JSUnusedLocalSymbols
  constructor(private postalService: PostalService) {
  }
}
