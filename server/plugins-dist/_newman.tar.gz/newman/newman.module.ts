import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {routing} from './newman.routing';
import {Newman} from './newman.component';
import {NgaModule} from '../../../theme/nga.module';
import {WebPageModule} from "../../../../ng2-components/webpage/webpage.module";

//noinspection JSUnusedGlobalSymbols
@NgModule({
  imports: [
    CommonModule,
    WebPageModule,
    NgaModule,
    routing
  ],
  declarations: [
    Newman
  ],
  providers: []
})
export class NewmanModule {
}
