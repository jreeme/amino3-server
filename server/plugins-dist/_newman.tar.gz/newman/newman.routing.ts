import {Routes, RouterModule} from '@angular/router';

import {ModuleWithProviders} from '@angular/core';
import {Newman} from "./newman.component";

// noinspection TypeScriptValidateTypes
export const routes: Routes = [
  {
    path: '',
    component: Newman,
    children: []
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
