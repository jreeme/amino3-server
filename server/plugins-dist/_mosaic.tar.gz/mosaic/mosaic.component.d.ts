import { PostalService } from '../../../_services/postal.service';
export declare class Mosaic {
    private postalService;
    sourceUrl: string;
    constructor(postalService: PostalService);
}
