export declare class MosaicModule {
}
