"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var mosaic_component_1 = require("./mosaic.component");
exports.routes = [
    {
        path: '',
        component: mosaic_component_1.Mosaic,
        children: []
    }
];
exports.routing = router_1.RouterModule.forChild(exports.routes);
//# sourceMappingURL=mosaic.routing.js.map