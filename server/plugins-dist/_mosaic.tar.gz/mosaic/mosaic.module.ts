import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {routing} from './mosaic.routing';
import {Mosaic} from './mosaic.component';
import {NgaModule} from '../../../theme/nga.module';
import {WebPageModule} from "../../../../ng2-components/webpage/webpage.module";

//noinspection JSUnusedGlobalSymbols
@NgModule({
  imports: [
    CommonModule,
    WebPageModule,
    NgaModule,
    routing
  ],
  declarations: [
    Mosaic
  ],
  providers: []
})
export class MosaicModule {
}
