import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {routing} from './mosaic.routing';
import {Mosaic} from './mosaic.component';
import {NgaModule} from '../../../theme/nga.module';
import {WebPage} from '../../../../ng2-components/webpage/webpage.component';

//noinspection JSUnusedGlobalSymbols
@NgModule({
  imports: [
    CommonModule,
    NgaModule,
    routing
  ],
  declarations: [
    Mosaic,
    WebPage
  ],
  providers: []
})
export class MosaicModule {
}
