import { Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
export declare const routes: Routes;
export declare const routing: ModuleWithProviders;
