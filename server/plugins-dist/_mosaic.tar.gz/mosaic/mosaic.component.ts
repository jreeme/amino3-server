import {Component} from '@angular/core';
import {PostalService} from '../../../../ng2-services/postal.service';
@Component({
  selector: 'mosaic',
  template: `
    <webpage [sourceUrl]="sourceUrl"></webpage>
  `
})
export class Mosaic {
  sourceUrl = '/dashboard';
  //noinspection JSUnusedLocalSymbols
  constructor(private postalService: PostalService) {
  }
}
