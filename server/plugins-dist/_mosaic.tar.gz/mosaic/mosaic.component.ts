import {Component} from '@angular/core';
import {PostalService} from '../../../_services/postal.service';
@Component({
  selector: 'mosaic',
  template: `
    <webpage [sourceUrl]="sourceUrl"></webpage>
<!--    <ba-card title="Mosaic">-->
<!--      <iframe src="/dashboard" frameborder="0" width="100%" height="740px"></iframe>-->
<!--    </ba-card>-->
  `
})
export class Mosaic {
  sourceUrl = '/dashboard';
  //noinspection JSUnusedLocalSymbols
  constructor(private postalService: PostalService) {
  }
}
