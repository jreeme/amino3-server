export declare class Forms {
    constructor();
}
