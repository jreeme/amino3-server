export declare class ValidationInputs {
    checkboxModel: {
        name: string;
        state: boolean;
        class: string;
    }[];
    checkboxPropertiesMapping: {
        model: string;
        value: string;
        label: string;
        baCheckboxClass: string;
    };
    constructor();
}
