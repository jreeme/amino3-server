export declare class CheckboxInputs {
    checkboxModel: {
        name: string;
        checked: boolean;
        class: string;
    }[];
    isDisabled: boolean;
    checkboxPropertiesMapping: {
        model: string;
        value: string;
        label: string;
        baCheckboxClass: string;
    };
    constructor();
}
