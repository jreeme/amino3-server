export declare class InlineForm {
    constructor();
    isRemember: boolean;
}
