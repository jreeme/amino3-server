export * from './withoutLabelsForm.component';
