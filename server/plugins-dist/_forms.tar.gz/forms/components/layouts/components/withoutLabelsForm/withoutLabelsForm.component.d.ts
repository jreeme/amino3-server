export declare class WithoutLabelsForm {
    constructor();
}
