export declare class BlockForm {
    constructor();
}
