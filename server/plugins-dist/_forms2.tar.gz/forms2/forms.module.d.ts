export declare class FormsModule {
}
