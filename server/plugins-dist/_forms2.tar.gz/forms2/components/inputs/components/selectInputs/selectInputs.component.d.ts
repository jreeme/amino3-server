export declare class SelectInputs {
    constructor();
}
