export declare class StandardInputs {
    constructor();
}
