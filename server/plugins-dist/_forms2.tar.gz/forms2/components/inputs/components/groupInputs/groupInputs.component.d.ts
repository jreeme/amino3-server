export declare class GroupInputs {
    constructor();
}
