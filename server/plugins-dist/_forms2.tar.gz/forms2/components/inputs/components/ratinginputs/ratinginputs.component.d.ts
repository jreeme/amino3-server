export declare class Rating {
    _rate1: number;
    _rate2: number;
    _max1: number;
    _max2: number;
    constructor();
}
