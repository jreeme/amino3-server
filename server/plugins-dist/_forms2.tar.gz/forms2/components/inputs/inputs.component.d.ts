export declare class Inputs {
    constructor();
}
