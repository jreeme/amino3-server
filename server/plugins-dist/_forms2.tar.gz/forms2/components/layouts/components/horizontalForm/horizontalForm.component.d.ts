export declare class HorizontalForm {
    constructor();
    isRemember: boolean;
}
