export declare class BasicForm {
    constructor();
    isChecked: boolean;
}
