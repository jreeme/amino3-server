import { NgUploaderOptions } from 'ngx-uploader';
export declare class Layouts {
    defaultPicture: string;
    profile: any;
    uploaderOptions: NgUploaderOptions;
    fileUploaderOptions: NgUploaderOptions;
    constructor();
    ngOnInit(): void;
}
